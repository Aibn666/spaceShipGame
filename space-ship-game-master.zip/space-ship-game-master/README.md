# SPACESHIP-VIDEO-GAME

This is a spaceship video game built in Javascript and Canvas.

**INTRUCTIONS:**

1.- Use up, down, left and right arrows from keyboard to move spaceship or click on left and right buttons

2.- Shooting could be done by either pressing the "space button" from keyboard or by clicking on the "Fire Missile" button.
